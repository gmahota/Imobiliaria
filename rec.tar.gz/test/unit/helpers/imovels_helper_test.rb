require 'test_helper'

class ImovelsHelperTest < ActionView::TestCase
end
