require 'test_helper'

class FotosrespostaHelperTest < ActionView::TestCase
end
