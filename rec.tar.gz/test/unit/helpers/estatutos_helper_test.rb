require 'test_helper'

class EstatutosHelperTest < ActionView::TestCase
end
