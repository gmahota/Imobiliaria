require 'test_helper'

class TipoNegociosHelperTest < ActionView::TestCase
end
