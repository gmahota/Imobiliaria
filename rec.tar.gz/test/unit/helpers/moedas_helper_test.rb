require 'test_helper'

class MoedasHelperTest < ActionView::TestCase
end
