require 'test_helper'

class CidadesHelperTest < ActionView::TestCase
end
