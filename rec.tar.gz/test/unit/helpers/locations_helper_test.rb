require 'test_helper'

class LocationsHelperTest < ActionView::TestCase
end
