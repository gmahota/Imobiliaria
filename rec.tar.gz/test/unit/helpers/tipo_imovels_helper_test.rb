require 'test_helper'

class TipoImovelsHelperTest < ActionView::TestCase
end
