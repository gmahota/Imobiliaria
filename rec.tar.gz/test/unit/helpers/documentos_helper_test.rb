require 'test_helper'

class DocumentosHelperTest < ActionView::TestCase
end
