require 'test_helper'

class CompaniesHelperTest < ActionView::TestCase
end
