require 'test_helper'

class EstadosHelperTest < ActionView::TestCase
end
