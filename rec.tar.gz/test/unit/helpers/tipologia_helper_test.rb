require 'test_helper'

class TipologiaHelperTest < ActionView::TestCase
end
