require 'test_helper'

class TipoNegocioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
