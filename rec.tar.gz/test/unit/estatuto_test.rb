require 'test_helper'

class EstatutoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
