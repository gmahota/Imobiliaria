require 'test_helper'

class MoedaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
