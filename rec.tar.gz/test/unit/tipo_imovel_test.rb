require 'test_helper'

class TipoImovelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
