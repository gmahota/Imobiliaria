require 'test_helper'

class FotosrespostaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
