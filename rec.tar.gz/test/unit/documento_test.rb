require 'test_helper'

class DocumentoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
