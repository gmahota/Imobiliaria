require 'test_helper'

class ImovelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
