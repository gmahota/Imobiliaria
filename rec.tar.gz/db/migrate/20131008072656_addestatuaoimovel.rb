class Addestatuaoimovel < ActiveRecord::Migration
  def up
  	
  end

  def down
  end
end
