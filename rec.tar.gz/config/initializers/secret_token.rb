# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MicroApp::Application.config.secret_token = '0e544fda49e901ea550af379d8ed8d922f57ece180243a54b692c5f2b63cb59e7bdd7d750df0e40c1a8ddced0cc5da68f6ab38b4b064ca2769e7aa6c55e6adea'
