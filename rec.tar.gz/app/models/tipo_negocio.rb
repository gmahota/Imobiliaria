class TipoNegocio < ActiveRecord::Base
  attr_accessible :descricao
end
