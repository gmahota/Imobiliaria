class Estado < ActiveRecord::Base
  attr_accessible :descricao
end
