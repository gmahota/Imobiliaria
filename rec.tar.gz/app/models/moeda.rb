class Moeda < ActiveRecord::Base
  attr_accessible :descricao, :sigla
end
